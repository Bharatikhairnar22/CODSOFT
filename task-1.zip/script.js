// JavaScript for product slider

const slider = document.querySelector('.product-slider');
const scrollStep = 1;
const scrollSpeed = 15; // Lower value for faster animation
let scrollAmount = 0;
let isSliding = true;

function startSlider() {
    if (!isSliding) return;

    slider.style.transform = `translateX(${scrollAmount}px)`;
    scrollAmount -= scrollStep;
    if (scrollAmount <= -slider.scrollWidth / 3) {
        scrollAmount = 0;
    }

